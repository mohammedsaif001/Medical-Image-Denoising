const teamDetails = [
    {
        image: 'https://media-exp1.licdn.com/dms/image/D4D03AQGGRqg7IOg_cg/profile-displayphoto-shrink_800_800/0/1637682265645?e=1654128000&v=beta&t=1qm2V282di62Rlh7-SixUC__bLS8QDiL7s0SP6gzZ-I',
        personName: 'Prof Yamanappa',
        title: 'Assistant Professor - CSE',
        content: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta reprehenderit magni quas consequuntur neque ex quisquam! .',
        linkedin: '',
        email: '',
        github: '',
        instagram: ''
    },
    {
        image: 'https://media-exp1.licdn.com/dms/image/D4D03AQGGRqg7IOg_cg/profile-displayphoto-shrink_800_800/0/1637682265645?e=1654128000&v=beta&t=1qm2V282di62Rlh7-SixUC__bLS8QDiL7s0SP6gzZ-I',
        personName: 'Mohammed Saif',
        title: '20181CSE0433',
        content: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta reprehenderit magni quas consequuntur neque ex quisquam!.',
        linkedin: 'https://www.linkedin.com/in/mohammedsaif001/',
        email: 'mdsaif4online@gmail.com',
        github: 'https://github.com/mohammedsaif001',
        instagram: 'https://www.instagram.com/mohammedsaif001/'
    },
    {
        image: 'https://media-exp1.licdn.com/dms/image/D4D03AQGGRqg7IOg_cg/profile-displayphoto-shrink_800_800/0/1637682265645?e=1654128000&v=beta&t=1qm2V282di62Rlh7-SixUC__bLS8QDiL7s0SP6gzZ-I',
        personName: 'Mohammed Abdullah',
        title: '20181CSE0433',
        content: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta reprehenderit magni quas consequuntur neque ex quisquam! .',
        linkedin: '',
        email: '',
        github: '',
        instagram: ''
    },
    {
        image: 'https://media-exp1.licdn.com/dms/image/D4D03AQGGRqg7IOg_cg/profile-displayphoto-shrink_800_800/0/1637682265645?e=1654128000&v=beta&t=1qm2V282di62Rlh7-SixUC__bLS8QDiL7s0SP6gzZ-I',
        personName: 'Syed Yunus',
        title: '20181CSE0737 ',
        content: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta reprehenderit magni quas consequuntur neque ex quisquam!.',
        linkedin: 'https://www.linkedin.com/in/syed-yunus-b677531a9',
        email: 'syedyunusstar@gmail.com ',
        github: 'https://github.com/wideflare/',
        instagram: 'https://www.instagram.com/syedyunusstar/'
    },
    {
        image: process.env.PUBLIC_URL + "images/nishithaa_photo.jpg",
        personName: 'Nishitaa Palani',
        title: '20181CSE0490',
        content: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta reprehenderit magni quas consequuntur neque ex quisquam! .',
        linkedin: 'https://www.linkedin.com/in/nishithaa-palani/',
        email: 'nishithaapalani@gmail.com ',
        github: 'https://github.com/NishithaaPalani/NP.git',
        instagram: 'https://www.instagram.com/nishithaa_palani/'
    },
    {
        image: 'https://media-exp1.licdn.com/dms/image/D4D03AQGGRqg7IOg_cg/profile-displayphoto-shrink_800_800/0/1637682265645?e=1654128000&v=beta&t=1qm2V282di62Rlh7-SixUC__bLS8QDiL7s0SP6gzZ-I',
        personName: 'Mohammed Uvais',
        title: '20181CSE0433',
        content: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta reprehenderit magni quas consequuntur neque ex quisquam!.',
        linkedin: '',
        email: '',
        github: '',
        instagram: ''
    }
]

export default teamDetails